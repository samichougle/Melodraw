//
//  MelodrawApp.swift
// Melodraw
//
//  Created by sami chougle on 06/01/25.
//

import SwiftUI

@main
struct Melodraw: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
